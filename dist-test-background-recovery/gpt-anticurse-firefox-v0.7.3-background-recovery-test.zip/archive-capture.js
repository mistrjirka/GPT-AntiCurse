/*
 * Transient history bridge and on-demand export capture.
 *
 * Normal browsing never persists conversation text and installs no mutation
 * observers. Chromium keeps the untouched response-derived visible history in
 * this content-script lifetime so the lightweight older-history view can work.
 * Firefox keeps equivalent per-tab history in its background event page.
 *
 * When the user explicitly exports, AntiCurse fetches the authenticated cursor-
 * paginated conversation graph in memory, reconciles the currently rendered tail,
 * and returns one archive to the popup. Nothing is written to IndexedDB.
 */
(() => {
  "use strict";

  const ext = typeof browser !== "undefined" ? browser : chrome;
  const CHANNEL = "__gpt_anticurse_v1__";
  const NETWORK_ARCHIVE_EVENT = "__gpt_anticurse_archive_ready__";
  const TURN_SELECTOR = '[data-testid^="conversation-turn-"]';
  const ROLE_SELECTOR = '[data-message-author-role="user"], [data-message-author-role="assistant"]';
  const EXPORT_CAPTURE_TAIL_TURNS = 96;
  const EXPORT_MAX_PAGES = 100;
  const DIAGNOSTICS = globalThis.CGAntiCurseDiagnostics;
  const EXPORT_EXTRACT = globalThis.CGExportExtract;
  const SESSION_AUTH = globalThis.CGAntiCurseSessionAuth;
  const scope = globalThis.CGConversationScope.create();
  const IS_FIREFOX = !!(ext.runtime.getManifest().browser_specific_settings?.gecko);

  let latestNetworkArchive = null;
  let latestFullVisibleArchive = null;
  let confirmedConversationId = null;

  function recordIssue(code, error, extra) {
    if (DIAGNOSTICS && typeof DIAGNOSTICS.record === "function") return DIAGNOSTICS.record("archive", code, error, extra);
    console.warn(`[GPT AntiCurse] archive/${code}`, error, extra || "");
    return Promise.resolve(null);
  }

  function syncScope() {
    if (!scope.sync()) return false;
    const id = scope.currentId();
    if (!latestNetworkArchive || latestNetworkArchive.id !== id) latestNetworkArchive = null;
    if (!latestFullVisibleArchive || latestFullVisibleArchive.id !== id) latestFullVisibleArchive = null;
    confirmedConversationId = null;
    return true;
  }

  function confirmConversation(id) {
    syncScope();
    if (!id || id !== scope.currentId()) return false;
    confirmedConversationId = id;
    return true;
  }

  function acceptNetworkArchive(archive) {
    if (!archive || !archive.id || !Array.isArray(archive.messages)) {
      recordIssue("invalid-network-archive", "MAIN world supplied an invalid transient conversation history.");
      return false;
    }
    syncScope();
    const currentId = scope.currentId();
    if (currentId && archive.id !== currentId) return false;
    latestNetworkArchive = archive;
    confirmedConversationId = archive.id;
    window.dispatchEvent(new Event(NETWORK_ARCHIVE_EVENT));
    return true;
  }

  globalThis.CGAntiCurseArchiveBridge = {
    get(id) {
      syncScope();
      const requestedId = id || scope.currentId();
      if (!requestedId || !latestNetworkArchive || latestNetworkArchive.id !== requestedId) return null;
      return latestNetworkArchive;
    },
    buildFullVisibleArchive(id) {
      return buildFullVisibleArchive(id);
    },
    debug() {
      syncScope();
      const id = scope.currentId();
      const current = latestNetworkArchive && latestNetworkArchive.id === id ? latestNetworkArchive : null;
      return {
        conversationId: id,
        transientArchive: !!current,
        transientMessages: current && Array.isArray(current.messages) ? current.messages.length : 0,
        paginationCursorPreserved: !!(current && current.paginationCursor),
        fullVisibleArchive: !!(latestFullVisibleArchive && latestFullVisibleArchive.id === id),
        fullVisibleMessages: latestFullVisibleArchive && latestFullVisibleArchive.id === id ? latestFullVisibleArchive.messages.length : 0,
        archiveMode: "on-demand",
        persistentBackup: false,
        conversationConfirmed: !!id && confirmedConversationId === id,
        observersActive: false,
        capturePending: false,
        exportCaptureTailTurns: EXPORT_CAPTURE_TAIL_TURNS
      };
    }
  };

  function turnIndex(turn) {
    const testId = turn && turn.getAttribute ? turn.getAttribute("data-testid") : "";
    const match = String(testId || "").match(/^conversation-turn-(\d+)$/);
    return match ? Number(match[1]) : null;
  }

  function visibleText(roleElement) {
    const markdownBlocks = Array.from(roleElement.querySelectorAll(".markdown"));
    if (markdownBlocks.length) {
      const value = markdownBlocks.map((node) => node.textContent || "").join("\n\n").trim();
      if (value) return value;
    }
    return (roleElement.textContent || "").trim();
  }

  function collectRenderedMessages(limit = EXPORT_CAPTURE_TAIL_TURNS) {
    const root = document.querySelector("#thread");
    if (!root) return [];
    const result = [];
    const turns = Array.from(root.querySelectorAll(TURN_SELECTOR)).slice(-limit);
    if (turns.length) {
      for (const turn of turns) {
        const roleElement = turn.querySelector(ROLE_SELECTOR);
        if (!roleElement) continue;
        const role = roleElement.getAttribute("data-message-author-role");
        const text = visibleText(roleElement);
        if (text) result.push({ role, text, turnIndex: turnIndex(turn) });
      }
      return result;
    }
    for (const roleElement of Array.from(root.querySelectorAll(ROLE_SELECTOR)).slice(-limit)) {
      const role = roleElement.getAttribute("data-message-author-role");
      const text = visibleText(roleElement);
      if (text) result.push({ role, text, turnIndex: null });
    }
    return result;
  }

  function archiveFromHistory(history, id) {
    if (!history || history.ok === false || !Array.isArray(history.messages) || !id) return null;
    return {
      schemaVersion: 1,
      id,
      title: document.title || "ChatGPT conversation",
      sourceUrl: location.href,
      updatedAt: new Date().toISOString(),
      complete: true,
      messages: history.messages.map((message, index) => ({
        id: message.id || `history-${index}`,
        role: message.role,
        text: typeof message.text === "string" ? message.text : String(message.text || ""),
        createTime: message.createTime == null ? null : message.createTime
      }))
    };
  }

  async function authoritativeArchive(token) {
    syncScope();
    if (!scope.isCurrent(token) || !token.id) return null;
    if (latestNetworkArchive && latestNetworkArchive.id === token.id) return latestNetworkArchive;
    if (!IS_FIREFOX) return null;
    const history = await ext.runtime.sendMessage({
      type: "cg-get-window-history",
      conversationId: token.id,
      maxDisplayMessages: 64
    });
    if (!scope.isCurrent(token)) return null;
    return archiveFromHistory(history, token.id);
  }

  async function firefoxBypassHeader(token) {
    if (!IS_FIREFOX) return { ok: true, headers: {} };
    let grant;
    try {
      grant = await ext.runtime.sendMessage({ type: "cg-create-export-bypass", conversationId: token.id });
    } catch (error) {
      return { ok: false, reason: "export-bypass-grant-failed", error: String(error && error.message ? error.message : error) };
    }
    if (!grant || grant.ok !== true || !grant.token) {
      return { ok: false, reason: grant?.reason || "export-bypass-grant-failed" };
    }
    return { ok: true, headers: { "X-GPT-AntiCurse-Export": grant.token } };
  }

  function paginatedEnvelope(data) {
    return !!data &&
      typeof data === "object" &&
      !Array.isArray(data) &&
      Array.isArray(data.messages) &&
      !!data.page_info &&
      typeof data.page_info === "object" &&
      !Array.isArray(data.page_info);
  }

  function paginatedPageCursor(data) {
    if (!paginatedEnvelope(data) || data.page_info.has_previous_page !== true) return "";
    return typeof data.page_info.start_cursor === "string" ? data.page_info.start_cursor.trim() : "";
  }

  function paginatedMessagesToGraph(messages, conversationId, serverCurrentNode) {
    const ordered = [];
    const byId = new Map();
    for (const message of Array.isArray(messages) ? messages : []) {
      const id = String(message && message.id || "").trim();
      if (!id) continue;
      if (!byId.has(id)) ordered.push(id);
      byId.set(id, message);
    }
    const rootId = `paginated-root:${conversationId}`;
    const mapping = Object.create(null);
    mapping[rootId] = { id: rootId, parent: null, children: ordered.length ? [ordered[0]] : [] };
    for (let index = 0; index < ordered.length; index++) {
      const id = ordered[index];
      mapping[id] = {
        id,
        message: byId.get(id),
        parent: index === 0 ? rootId : ordered[index - 1],
        children: index + 1 < ordered.length ? [ordered[index + 1]] : []
      };
    }
    const requestedCurrent = String(serverCurrentNode || "").trim();
    const currentNode = requestedCurrent && mapping[requestedCurrent]
      ? requestedCurrent
      : ordered[ordered.length - 1] || rootId;
    return { mapping, root: rootId, currentNode };
  }

  function exportEndpointUrl(token, cursor, endpointFamily) {
    const encodedId = encodeURIComponent(token.id);
    const paginatedMessages = endpointFamily === "conversations" && !!cursor;
    const base = paginatedMessages
      ? `${location.origin}/backend-api/conversations/${encodedId}/messages`
      : `${location.origin}/backend-api/${endpointFamily}/${encodedId}`;
    const params = new URLSearchParams();
    if (endpointFamily === "conversations") {
      params.set("include_has_versions", "true");
      params.set("num_turns", "10");
      if (cursor) params.set("before", cursor);
    } else if (cursor) {
      params.set("cursor", cursor);
    }
    const query = params.toString();
    return query ? `${base}?${query}` : base;
  }

  async function fetchConversationPageFromFamily(token, accessToken, cursor, endpointFamily) {
    const endpointUrl = exportEndpointUrl(token, cursor, endpointFamily);
    const bypass = await firefoxBypassHeader(token);
    if (!bypass.ok) return { ...bypass, endpointUrl, endpointFamily };
    if (!scope.isCurrent(token)) return { ok: false, reason: "conversation-changed", endpointUrl, endpointFamily };

    let response;
    try {
      response = await fetch(endpointUrl, {
        method: "GET",
        credentials: "same-origin",
        cache: "no-store",
        headers: {
          accept: "application/json",
          authorization: `Bearer ${accessToken}`,
          ...bypass.headers
        }
      });
    } catch (error) {
      return { ok: false, reason: "network-failed", error: String(error && error.message ? error.message : error), endpointUrl, endpointFamily };
    }
    if (!response.ok) return { ok: false, reason: "http-status", status: response.status, endpointUrl, endpointFamily };
    if (IS_FIREFOX && response.headers.get("X-GPT-AntiCurse-Export-Bypassed") !== "1") {
      return { ok: false, reason: "export-bypass-unconfirmed", endpointUrl, endpointFamily };
    }
    try {
      const data = await response.json();
      if (!scope.isCurrent(token)) return { ok: false, reason: "conversation-changed", endpointUrl, endpointFamily };
      const mappingShape = !!data && typeof data === "object" && !!data.mapping && typeof data.mapping === "object" && !Array.isArray(data.mapping);
      const paginatedShape = endpointFamily === "conversations" && paginatedEnvelope(data);
      if (!mappingShape && !paginatedShape) {
        return { ok: false, reason: "unsupported-conversation-shape", endpointUrl, endpointFamily };
      }
      return { ok: true, data, shape: paginatedShape ? "paginated-messages" : "mapping", endpointUrl, endpointFamily };
    } catch (error) {
      return { ok: false, reason: "json-parse-failed", error: String(error && error.message ? error.message : error), endpointUrl, endpointFamily };
    }
  }

  function canFallbackToPlural(page, endpointFamily) {
    if (endpointFamily !== "conversation" || !page) return false;
    if (page.reason === "unsupported-conversation-shape") return true;
    return page.reason === "http-status" && [404, 405, 410].includes(Number(page.status));
  }

  async function fetchConversationPage(token, accessToken, cursor, endpointFamily = null) {
    const families = endpointFamily ? [endpointFamily] : ["conversation", "conversations"];
    let lastFailure = null;
    for (const family of families) {
      const page = await fetchConversationPageFromFamily(token, accessToken, cursor, family);
      if (page.ok) return page;
      lastFailure = page;
      if (endpointFamily || !canFallbackToPlural(page, family)) return page;
    }
    return lastFailure || { ok: false, reason: "conversation-endpoint-unavailable" };
  }

  async function fetchAuthoritativeConversation(token) {
    if (!scope.isCurrent(token) || !token.id) return { ok: false, reason: "conversation-changed" };
    if (!SESSION_AUTH || typeof SESSION_AUTH.resolveAccessToken !== "function") {
      return { ok: false, reason: "session-auth-unavailable" };
    }
    const auth = await SESSION_AUTH.resolveAccessToken({ isCurrent: () => scope.isCurrent(token) });
    if (!auth.ok) return auth;

    const mapping = Object.create(null);
    const seenCursors = new Set();
    let rawMessages = [];
    let rawPaginated = false;
    let cursor = null;
    let currentNode = null;
    let title = "";
    let root = null;
    let conversationId = token.id;
    let pageCount = 0;
    let endpointUrl = null;
    let endpointFamily = null;

    while (pageCount < EXPORT_MAX_PAGES) {
      const page = await fetchConversationPage(token, auth.accessToken, cursor, endpointFamily);
      if (!page.ok) return { ...page, pageCount };
      endpointUrl = page.endpointUrl;
      endpointFamily = page.endpointFamily;
      const data = page.data;

      if (page.shape === "paginated-messages") {
        if (pageCount > 0 && !rawPaginated) return { ok: false, reason: "pagination-shape-changed", endpointUrl, pageCount };
        rawPaginated = true;
        // The current endpoint returns newest page first; each `before` request is
        // an older chronological slice, so prepend it to reconstruct oldest->newest.
        rawMessages = (Array.isArray(data.messages) ? data.messages : []).concat(rawMessages);
      } else {
        if (rawPaginated) return { ok: false, reason: "pagination-shape-changed", endpointUrl, pageCount };
        Object.assign(mapping, data.mapping || {});
      }

      if (!currentNode && data.current_node) currentNode = data.current_node;
      if (!title && typeof data.title === "string") title = data.title;
      if (!root && data.root) root = data.root;
      if (data.id || data.conversation_id) conversationId = data.id || data.conversation_id;
      pageCount++;

      const nextCursor = page.shape === "paginated-messages"
        ? paginatedPageCursor(data)
        : (typeof data.cursor === "string" ? data.cursor.trim() : "");
      if (!nextCursor) {
        cursor = null;
        break;
      }
      if (seenCursors.has(nextCursor)) {
        return { ok: false, reason: "pagination-cursor-repeated", endpointUrl, pageCount };
      }
      seenCursors.add(nextCursor);
      cursor = nextCursor;
    }

    if (cursor && pageCount >= EXPORT_MAX_PAGES) {
      return { ok: false, reason: "pagination-page-limit", endpointUrl, pageCount };
    }

    if (rawPaginated) {
      const graph = paginatedMessagesToGraph(rawMessages, conversationId, currentNode);
      Object.assign(mapping, graph.mapping);
      root = graph.root;
      currentNode = graph.currentNode;
    }

    if (!currentNode || !mapping[currentNode]) {
      return { ok: false, reason: "unsupported-conversation-shape", endpointUrl, pageCount };
    }
    return {
      ok: true,
      endpointUrl,
      endpointFamily,
      pageCount,
      authSource: auth.authSource || null,
      authFallbackReason: auth.authFallbackReason || null,
      data: {
        id: conversationId,
        conversation_id: conversationId,
        title,
        mapping,
        current_node: currentNode,
        root
      }
    };
  }

  function visibleHistoryArchive(rawArchive) {
    if (!rawArchive || !Array.isArray(rawArchive.messages)) return null;
    const messages = rawArchive.messages.filter((message) => {
      if (!message || message.hidden === true) return false;
      if (message.role !== "user" && message.role !== "assistant") return false;
      if (message.role !== "assistant") return true;
      const recipient = String(message.recipient || "").trim().toLowerCase();
      return !recipient || recipient === "all" || recipient === "assistant";
    }).map((message) => ({
      id: message.id,
      role: message.role,
      text: message.text,
      createTime: message.createTime == null ? null : message.createTime
    }));
    return { ...rawArchive, complete: true, messages };
  }

  async function buildFullVisibleArchive(requestedId) {
    syncScope();
    const token = scope.snapshot();
    if (!token.id || (requestedId && requestedId !== token.id)) return { ok: false, reason: "conversation-changed" };
    if (latestFullVisibleArchive && latestFullVisibleArchive.id === token.id) {
      return { ok: true, archive: latestFullVisibleArchive, cached: true };
    }
    const source = await fetchAuthoritativeConversation(token);
    if (!source.ok || !scope.isCurrent(token)) return source.ok ? { ok: false, reason: "conversation-changed" } : source;
    const rawArchive = EXPORT_EXTRACT && typeof EXPORT_EXTRACT.createArchive === "function"
      ? EXPORT_EXTRACT.createArchive(source.data, { id: token.id, title: source.data?.title, sourceUrl: location.href })
      : null;
    const archive = visibleHistoryArchive(rawArchive);
    if (!archive) return { ok: false, reason: "history-extract-failed" };
    latestFullVisibleArchive = archive;
    return {
      ok: true,
      archive,
      cached: false,
      sourcePages: source.pageCount,
      sourceAuth: source.authSource || null,
      sourceEndpointFamily: source.endpointFamily || null
    };
  }

  async function buildExportCapture() {
    syncScope();
    const token = scope.snapshot();
    if (!token.id) return { ok: false, reason: "not-a-conversation" };

    const source = await fetchAuthoritativeConversation(token);
    if (!scope.isCurrent(token)) return { ok: false, reason: "conversation-changed", conversationId: token.id };

    let baseArchive = null;
    let authoritative = false;
    if (source.ok) {
      baseArchive = EXPORT_EXTRACT && typeof EXPORT_EXTRACT.createArchive === "function"
        ? EXPORT_EXTRACT.createArchive(source.data, {
            id: token.id,
            title: source.data && source.data.title,
            sourceUrl: location.href
          })
        : null;
      authoritative = !!baseArchive;
    }

    if (!baseArchive) {
      try {
        baseArchive = await authoritativeArchive(token);
      } catch (error) {
        await recordIssue("export-history-read-failed", error, { conversationId: token.id });
      }
      if (baseArchive) baseArchive = { ...baseArchive, complete: false };
    }
    if (!scope.isCurrent(token)) return { ok: false, reason: "conversation-changed", conversationId: token.id };

    const rendered = collectRenderedMessages(EXPORT_CAPTURE_TAIL_TURNS);
    if (authoritative && baseArchive && EXPORT_EXTRACT && typeof EXPORT_EXTRACT.mergeRenderedTail === "function") {
      baseArchive = EXPORT_EXTRACT.mergeRenderedTail(baseArchive, rendered);
    }
    if (!baseArchive && !rendered.length) {
      return { ok: false, reason: source.reason || "archive-not-found", conversationId: token.id };
    }
    if (!source.ok) {
      await recordIssue("export-source-fetch-failed", source.error || source.reason || "Authoritative export fetch failed", {
        conversationId: token.id,
        reason: source.reason || null,
        status: Number(source.status) || null
      });
    }
    return {
      ok: true,
      conversationId: token.id,
      title: source.data?.title || document.title,
      sourceUrl: location.href,
      authoritative,
      sourceReason: source.ok ? null : source.reason,
      sourcePages: source.ok ? source.pageCount : Number(source.pageCount) || 0,
      sourceAuth: source.ok ? source.authSource : null,
      sourceEndpointFamily: source.ok ? source.endpointFamily || null : null,
      baseArchive,
      // Authoritative raw archives already reconcile the rendered tail against
      // their visible projection. Partial fallbacks still use the legacy popup merge.
      rendered: authoritative ? [] : rendered
    };
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const message = event.data;
    if (!message || message.channel !== CHANNEL || message.type !== "archive") return;
    acceptNetworkArchive(message.archive);
  });

  ext.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message) return false;
    if (message.type === "cg-conversation-scope" && message.conversationId) {
      confirmConversation(message.conversationId);
      return false;
    }
    if (message.type === "cg-window-history" && message.history && message.history.conversationId) {
      confirmConversation(message.history.conversationId);
      return false;
    }
    if (message.type === "cg-build-export-archive") {
      buildExportCapture().then(sendResponse).catch((error) => {
        recordIssue("on-demand-export-failed", error);
        sendResponse({ ok: false, reason: String(error && error.message ? error.message : error) });
      });
      return true;
    }
    return false;
  });
})();
